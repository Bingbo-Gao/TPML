setwd("D:\\MyPaper\\Sample\\TPML_v2.0")

Sys.setenv(JAVA_HOME='C:\\Program Files\\Java\\jre1.8.0_191')

library("ranger")
library(xlsx)
library(sp)
library(gstat)


source("basic.r")


data = read.xlsx('BData.xlsx',1,encoding="UTF-8")

data$solitype<-as.factor(data$solitype)
data$DiMao<-as.factor(data$DiMao)
data$PlantType<-as.factor(data$PlantType)
data$LUCC2015<-as.factor(data$LUCC2015)
data$LUCC2010<-as.factor(data$LUCC2010)
data$LUCC2005<-as.factor(data$LUCC2005)
data$LUCC2000<-as.factor(data$LUCC2000)
data$LUCC95<-as.factor(data$LUCC95)
data$LUCC90<-as.factor(data$LUCC90)
data$LUCC80<-as.factor(data$LUCC80)

targetVar<-"TargetVar"
resultsMAE<-c()
resultsRMSE<-c()
quantiles = c((1-.682)/2, 0.5, 1-(1-.682)/2)

for (sSize in seq(50,100,by=100))
{
  mae<-c()
  rmse<-c()
  sample<-read.csv(paste("data\\Sample",sSize,".csv",sep=""))
  trainInd<-sample$ID
  
  #trainInd<-sample(nrow(data),round(nrow(data)*0.7))
  trainData<-data[trainInd,]
  testData<-data[-trainInd,]
  
  
  
  ################################    Two point RF         ################
  
  trainDiff<-distanceCrossSign(trainData,c(targetVar,"DEM","Slope","NDVI","LUCC2015","LUCC2010","LUCC2005","LUCC2000","LUCC95","LUCC90","LUCC80","GDP15","GDP95","POP15","POP95","DiMao","solitype","PlantType","clay","sand","silt","TWI","Atavg","Aravg","x","y"))
  
  #geodis<-distanceCrossGeo(trainData,xName="x",yName="y")
  #trainDiff<-cbind(trainDiff,geodis)
  
  names(trainDiff)<-c(targetVar,"DEM","Slope","NDVI","LUCC2015_f","LUCC2015_l","LUCC2010_f","LUCC2010_l","LUCC2005_f","LUCC2005_l","LUCC2000_f","LUCC2000_l","LUCC95_f","LUCC95_l","LUCC90_f","LUCC90_l","LUCC80_f","LUCC80_l","GDP15","GDP95","POP15","POP95","DiMao_f","DiMao_l","solitype_f","solitype_l","PlantType_f","PlantType_l","clay","sand","silt","TWI","Atavg","Aravg","x","y")
  
  fmDif <- as.formula(paste(targetVar,"~ .",sep=""))
  dif.rf <- ranger(fmDif, trainDiff, num.trees=500, importance = "impurity", seed=1,respect.unordered.factors="order",keep.inbag=TRUE,quantreg=TRUE)
  
  
  print(predict(dif.rf,data.frame(DEM=0,	Slope=0,	NDVI=0,	LUCC2015_f=0,	LUCC2015_l=0,	LUCC2010_f=0,	LUCC2010_l=0,	LUCC2005_f=0,	LUCC2005_l=0,	LUCC2000_f=0,	LUCC2000_l=0,	LUCC95_f=0,	LUCC95_l=0,	LUCC90_f=0,	LUCC90_l=0,	LUCC80_f=0,	LUCC80_l=0,	GDP15=0,	GDP95=0,	POP15=0,	POP95=0,	DiMao_f=0,	DiMao_l=0,	solitype_f=0,	solitype_l=0,	PlantType_f=0,	PlantType_l=0,	clay=0,	sand=0,	silt=0,	TWI=0,	Atavg=0,	Aravg=0,	x=0,	y=0))$predictions)
  
  meanStd<-c()
  predDetail<-c()
  for(i in 1:nrow(testData))
  {
    testOne<-testData[i,]
    
    testDif<-distanceSign(testOne,trainData,c(targetVar,"DEM","Slope","NDVI","LUCC2015","LUCC2010","LUCC2005","LUCC2000","LUCC95","LUCC90","LUCC80","GDP15","GDP95","POP15","POP95","DiMao","solitype","PlantType","clay","sand","silt","TWI","Atavg","Aravg","x","y"))
    
    #testGeoDis<-distanceBtwGeo(testOne,trainData, xName="x",yName="y")
    #testDif<-cbind(testDif,testGeoDis)
    
    names(testDif)<-c(targetVar,"DEM","Slope","NDVI","LUCC2015_f","LUCC2015_l","LUCC2010_f","LUCC2010_l","LUCC2005_f","LUCC2005_l","LUCC2000_f","LUCC2000_l","LUCC95_f","LUCC95_l","LUCC90_f","LUCC90_l","LUCC80_f","LUCC80_l","GDP15","GDP95","POP15","POP95","DiMao_f","DiMao_l","solitype_f","solitype_l","PlantType_f","PlantType_l","clay","sand","silt","TWI","Atavg","Aravg","x","y")
    
    dif.pred <- predict(dif.rf,testDif,type="quantiles", quantiles=quantiles)
    
    predDetail<-dif.pred$predictions
    
    stdEstimated<-(predDetail[,3]-predDetail[,1])/2
    
    usedPred<-order(abs(predDetail[,2]))[1:20]
    
    meanStd<-c(meanStd,mean((stdEstimated[usedPred])))
    
  }
  
  predDetail<-cbind(predDetail,trainData[,targetVar])
  
  write.csv(predDetail,file=paste("data\\quantileDetail",targetVar,sSize,".csv",sep=""))
  
  testData<-cbind(testData,meanStd)
  
  write.csv(testData,file=paste("data\\MstdforTestData",sSize,".csv",sep=""))
  
  
  
}



