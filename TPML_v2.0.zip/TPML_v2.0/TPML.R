TPMLTrain<- function(trainData,targetVar)
{
  ################################    Two point RF         ################
  
  trainDiff<-distanceCrossSign(trainData,c(targetVar,"DEM","Slope","NDVI","LUCC2015","LUCC2010","LUCC2005","LUCC2000","LUCC95","LUCC90","LUCC80","GDP15","GDP95","POP15","POP95","DiMao","solitype","PlantType","clay","sand","silt","TWI","Atavg","Aravg","x","y"))
  
  #geodis<-distanceCrossGeo(trainData,xName="x",yName="y")
  #trainDiff<-cbind(trainDiff,geodis)
  
  names(trainDiff)<-c(targetVar,"DEM","Slope","NDVI","LUCC2015_f","LUCC2015_l","LUCC2010_f","LUCC2010_l","LUCC2005_f","LUCC2005_l","LUCC2000_f","LUCC2000_l","LUCC95_f","LUCC95_l","LUCC90_f","LUCC90_l","LUCC80_f","LUCC80_l","GDP15","GDP95","POP15","POP95","DiMao_f","DiMao_l","solitype_f","solitype_l","PlantType_f","PlantType_l","clay","sand","silt","TWI","Atavg","Aravg","x","y")
  print(trainDiff)
  fmDif <- as.formula(paste(targetVar,"~ .",sep=""))
  dif.rf <- ranger(fmDif, trainDiff, num.trees=500, importance = "impurity", seed=1,respect.unordered.factors="order")
  
  return (dif.rf)
  
}  


TPMLPredictOne<- function(testData,trainData,targetVar,model,inta)  
{
  
  predValues<-c()
  testOne<-testData
  
  testDif<-distanceSign(testOne,trainData,c(targetVar,"DEM","Slope","NDVI","LUCC2015","LUCC2010","LUCC2005","LUCC2000","LUCC95","LUCC90","LUCC80","GDP15","GDP95","POP15","POP95","DiMao","solitype","PlantType","clay","sand","silt","TWI","Atavg","Aravg","x","y"))
  
  #testGeoDis<-distanceBtwGeo(testOne,trainData, xName="x",yName="y")
  #testDif<-cbind(testDif,testGeoDis)
  
  names(testDif)<-c(targetVar,"DEM","Slope","NDVI","LUCC2015_f","LUCC2015_l","LUCC2010_f","LUCC2010_l","LUCC2005_f","LUCC2005_l","LUCC2000_f","LUCC2000_l","LUCC95_f","LUCC95_l","LUCC90_f","LUCC90_l","LUCC80_f","LUCC80_l","GDP15","GDP95","POP15","POP95","DiMao_f","DiMao_l","solitype_f","solitype_l","PlantType_f","PlantType_l","clay","sand","silt","TWI","Atavg","Aravg","x","y")
  
  dif.pred <- predict(model,testDif)
  
  usedPred<-order(abs(dif.pred$predictions))[1:inta]
  
  predValue<-mean((trainData[,targetVar]+dif.pred$predictions)[usedPred],na.rm=TRUE)
  
  return (predValue)
  
}


TPMLPredict<- function(testData,trainData,targetVar,model,inta)  
{
  
  predValues<-c()
  
  for(i in 1:nrow(testData))
  {
    testOne<-testData[i,]
    
    testDif<-distanceSign(testOne,trainData,c(targetVar,"DEM","Slope","NDVI","LUCC2015","LUCC2010","LUCC2005","LUCC2000","LUCC95","LUCC90","LUCC80","GDP15","GDP95","POP15","POP95","DiMao","solitype","PlantType","clay","sand","silt","TWI","Atavg","Aravg","x","y"))
    
    #testGeoDis<-distanceBtwGeo(testOne,trainData, xName="x",yName="y")
    #testDif<-cbind(testDif,testGeoDis)
    
    names(testDif)<-c(targetVar,"DEM","Slope","NDVI","LUCC2015_f","LUCC2015_l","LUCC2010_f","LUCC2010_l","LUCC2005_f","LUCC2005_l","LUCC2000_f","LUCC2000_l","LUCC95_f","LUCC95_l","LUCC90_f","LUCC90_l","LUCC80_f","LUCC80_l","GDP15","GDP95","POP15","POP95","DiMao_f","DiMao_l","solitype_f","solitype_l","PlantType_f","PlantType_l","clay","sand","silt","TWI","Atavg","Aravg","x","y")
    
    dif.pred <- predict(model,testDif)
    
    usedPred<-order(abs(dif.pred$predictions))[1:inta]
    
    predValues<-c(predValues,mean((trainData[,targetVar]+dif.pred$predictions)[usedPred],na.rm=TRUE) )
    
  }
  
  predDetail<-cbind(predDetail,trainData[,targetVar])
  
  mae<-mean(abs(testData[,targetVar]-predValues))
  
  rmse<-sqrt(mean((testData[,targetVar]-predValues)^2))
  
  return (c(mae,rmse))
  
}