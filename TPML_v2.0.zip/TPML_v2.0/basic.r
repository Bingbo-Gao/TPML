distanceCrossSign<-function(data,targetVars)
{
  results<-c()
  n<-nrow(data)

  for(targetV in targetVars)
  {
    if(is.numeric(data[,targetV]))
    {
      values<-c()
      for(i in  1:n)
      {
        for(j in 1:n)
        {
          values<-c(values, (data[i,targetV]- data[j,targetV]))
        }
      }
      results<-cbind(results,values)
    }else
    {
      values1<-c()
      values2<-c()
      for(i in  1:n)
      {
        for(j in 1:n)
        {
          values1<-c(values1,data[i,targetV])
          values2<-c(values2,data[j,targetV])
        }
      }
      results<-cbind(results,values1,values2)
    }
    
  }
  
  results<-as.data.frame(results)
  
  names(results)<-targetVars
  
  return (results)
  
  #  distance<-function(emd1,emd2)
  #  {
  #    if(is.factor(emd1))
  #    {
  #      return (distanceCat(emd1,emd2))
  #    }else if(is.numeric(emd1))
  #    {
  #      return (distanceCon(emd1,emd2))
  #    }else
  #    {
  #      return (NA)
  #    }
  
  #  }
  
}


distanceSign<-function(former,latter,targetVars)
{
  results<-c()
  
 for(f in 1:nrow(former) )
 {
   for(l in 1:nrow(latter) )
   {
     values<-c()
     for(targetV in targetVars)
     {
       if(is.numeric(former[f,targetV]))
       {
         values<-c(values,former[f,targetV]-latter[l,targetV])
       }else
       {
         values<-c(values,former[f,targetV],latter[l,targetV])
       }
     }
     
     results<-rbind(results,values)
   }
 }
  
  results<-as.data.frame(results)
  
  names(results)<-targetVars
  
  return (results)
  
}
