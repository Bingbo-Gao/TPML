setwd("D:\\MyPaper\\Sample\\TPML_v2.0")



library("ranger")
library(xlsx)
library(sp)
library(gstat)


source("basic.r")
source("TPML.r")


data = read.xlsx('BData.xlsx',1,encoding="UTF-8")

data$solitype<-as.factor(data$solitype)
data$DiMao<-as.factor(data$DiMao)
data$PlantType<-as.factor(data$PlantType)
data$LUCC2015<-as.factor(data$LUCC2015)
data$LUCC2010<-as.factor(data$LUCC2010)
data$LUCC2005<-as.factor(data$LUCC2005)
data$LUCC2000<-as.factor(data$LUCC2000)
data$LUCC95<-as.factor(data$LUCC95)
data$LUCC90<-as.factor(data$LUCC90)
data$LUCC80<-as.factor(data$LUCC80)

targetVar<-"TargetVar"
#print(targetVar)
resultsMAE<-c()
resultsRMSE<-c()
resultsR<-c()

for (sSize in seq(50,100,by=100))
{
  
  mae<-c()
  rmse<-c()
  
  sample<-read.csv(paste("data\\Sample",sSize,".csv",sep=""))
  
  trainInd<-sample$ID
  
  #trainInd<-sample(nrow(data),round(nrow(data)*0.7))
  trainData<-data[trainInd,]
  
  model<-TPMLTrain(trainData,targetVar)
  
  for(inta in c(seq(10,(sSize-10),by=5),sSize-1))
  {
    
    predValues<-c()
    for(i in 1:sSize)
    {
      newTrainData<-trainData[-i,]
      testData<-trainData[i,]
      predValues<-c(predValues,TPMLPredictOne(testData,newTrainData,targetVar,model,inta)) 
    }
    
    mae<-c(mae,mean(abs(trainData[,targetVar]-predValues)))
    rmse<-c(rmse,sqrt(mean((trainData[,targetVar]-predValues)^2)))
    }
  
  
  write.csv(cbind(mae,rmse), file=paste("data\\OptInta",sSize,".csv",sep=""))
  
}


































