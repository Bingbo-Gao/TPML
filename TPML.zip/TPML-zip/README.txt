The experiment includes following five steps：

（1）Prepare data and extract the values of the covariates at all points.

（2）Draw samples with the size as 50, 100, 200, 300, 400 and 500 from the points with Mean of the Shortest Distances (MMSD) and Spatial Simulated Annealing (SSA).
Treat the points in each sample as an training data, and corresponding unselected points as validation data. Every row of the training data and data validation include one target  variable value and its covariates values. 
As in practice of spatial sampling, the spatially even coverage is most concerned. The training data of the cross validation here simulated the realistic spatial sampling with different sample size.

（3）Build two point random forest model (2PRF), LRK, RF, RFRK and fit the variograms with each training data set separately. 

（4）Predict the target  variable values at validation points using the 2PRF, OK, LRK, RF and RFRK.

（5）Compare the validation results of three methods.