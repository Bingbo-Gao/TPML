setwd("D:\\MyPaper\\Sample\\TPML")

Sys.setenv(JAVA_HOME='C:\\Program Files\\Java\\jre1.8.0_191')

library("ranger")
library(xlsx)
library(sp)
library(gstat)


source("basic.r")


data = read.xlsx('BData.xlsx',1,encoding="UTF-8")

data$solitype<-as.factor(data$solitype)
data$DiMao<-as.factor(data$DiMao)
data$PlantType<-as.factor(data$PlantType)
data$LUCC2015<-as.factor(data$LUCC2015)
data$LUCC2010<-as.factor(data$LUCC2010)
data$LUCC2005<-as.factor(data$LUCC2005)
data$LUCC2000<-as.factor(data$LUCC2000)
data$LUCC95<-as.factor(data$LUCC95)
data$LUCC90<-as.factor(data$LUCC90)
data$LUCC80<-as.factor(data$LUCC80)

targetVar<-"TargetVar"
resultsMAE<-c()
resultsRMSE<-c()


for (sSize in seq(100,500,by=100))
{
  mae<-c()
  rmse<-c()
  sample<-read.csv(paste("data\\Sample",sSize,".csv",sep=""))
  trainInd<-sample$ID
  
  #trainInd<-sample(nrow(data),round(nrow(data)*0.7))
  trainData<-data[trainInd,]
  testData<-data[-trainInd,]
  
  
  ################################    RF          ################
  fm1 <- as.formula(paste(targetVar," ~x+y+DEM+Slope+NDVI+LUCC2015+LUCC2010+LUCC2005+LUCC2000+LUCC95+LUCC90+LUCC80+GDP15+GDP95+POP15+POP95+DiMao+solitype+PlantType+clay+sand+silt+TWI+Atavg+Aravg",sep="") )
  
  rfModel <- ranger(fm1, trainData, num.trees=500, importance = "impurity", seed=1,respect.unordered.factors="order")
  
  importance<-rfModel$variable.importance/sum(rfModel$variable.importance)
  
  rfPredict<- predict(rfModel,data=testData)
  
  
  #print(mean(abs(testData$Cd-rfPredict$predictions)))
  
  mae<-c(mae,mean(abs(testData[,targetVar]-rfPredict$predictions)))
  rmse<-c(rmse, sqrt(mean((testData[,targetVar]-rfPredict$predictions)^2)))
  
  ################################    Two point RF         ################
  
  trainDiff<-distanceCrossSign(trainData,c(targetVar,"DEM","Slope","NDVI","LUCC2015","LUCC2010","LUCC2005","LUCC2000","LUCC95","LUCC90","LUCC80","GDP15","GDP95","POP15","POP95","DiMao","solitype","PlantType","clay","sand","silt","TWI","Atavg","Aravg","x","y"))
  
  #geodis<-distanceCrossGeo(trainData,xName="x",yName="y")
  #trainDiff<-cbind(trainDiff,geodis)
  
  names(trainDiff)<-c(targetVar,"DEM","Slope","NDVI","LUCC2015_f","LUCC2015_l","LUCC2010_f","LUCC2010_l","LUCC2005_f","LUCC2005_l","LUCC2000_f","LUCC2000_l","LUCC95_f","LUCC95_l","LUCC90_f","LUCC90_l","LUCC80_f","LUCC80_l","GDP15","GDP95","POP15","POP95","DiMao_f","DiMao_l","solitype_f","solitype_l","PlantType_f","PlantType_l","clay","sand","silt","TWI","Atavg","Aravg","x","y")
  
  fmDif <- as.formula(paste(targetVar,"~ .",sep=""))
  dif.rf <- ranger(fmDif, trainDiff, num.trees=500, importance = "impurity", seed=1,respect.unordered.factors="order")
  
  
  #print(predict(dif.rf,data.frame(DEM=0,Slope=0,NDVI=0,LUCC2015_f=0,LUCC2015_l=0,LUCC2010_f=0,LUCC2010_l=0,LUCC2005_f=0,LUCC2005_l=0,LUCC2000_f=0,LUCC2000_l=0,LUCC95_f=0,LUCC95_l=0,LUCC90_f=0,LUCC90_l=0,LUCC80_f=0,LUCC80_l=0,GDP15=0,GDP95=0,POP15=0,POP95=0,DiMao_f=0,DiMao_l=0,solitype_f=0,solitype_l=0,PlantType_f=0,PlantType_l=0,clay=0,sand=0,silt=0,TWI=0,
                                #  Atavg=0,Aravg=0,x=0,y=0))$predictions)
  
  predValues<-c()
  predDetail<-c()
  for(i in 1:nrow(testData))
  {
    testOne<-testData[i,]
    
    testDif<-distanceSign(testOne,trainData,c(targetVar,"DEM","Slope","NDVI","LUCC2015","LUCC2010","LUCC2005","LUCC2000","LUCC95","LUCC90","LUCC80","GDP15","GDP95","POP15","POP95","DiMao","solitype","PlantType","clay","sand","silt","TWI","Atavg","Aravg","x","y"))
    
    #testGeoDis<-distanceBtwGeo(testOne,trainData, xName="x",yName="y")
    #testDif<-cbind(testDif,testGeoDis)
    
    names(testDif)<-c(targetVar,"DEM","Slope","NDVI","LUCC2015_f","LUCC2015_l","LUCC2010_f","LUCC2010_l","LUCC2005_f","LUCC2005_l","LUCC2000_f","LUCC2000_l","LUCC95_f","LUCC95_l","LUCC90_f","LUCC90_l","LUCC80_f","LUCC80_l","GDP15","GDP95","POP15","POP95","DiMao_f","DiMao_l","solitype_f","solitype_l","PlantType_f","PlantType_l","clay","sand","silt","TWI","Atavg","Aravg","x","y")
    
    dif.pred <- predict(dif.rf,testDif)
    
    predDetail<-cbind(predDetail,dif.pred$predictions)
    
    usedPred<-order(abs(dif.pred$predictions))[1:20]
    
    predValues<-c(predValues,mean((trainData[,targetVar]+dif.pred$predictions)[usedPred],na.rm=TRUE) )
    
  }
  
  predDetail<-cbind(predDetail,trainData[,targetVar])
  
  write.csv(predDetail,file=paste("data\\Detail",targetVar,sSize,".csv",sep=""))
  
  write.csv(testData,file=paste("data\\TestDatafor",sSize,".csv",sep=""))
  
  
  mae<-c(mae,mean(abs(testData[,targetVar]-predValues)))
  
  rmse<-c(rmse, sqrt(mean((testData[,targetVar]-predValues)^2)))
  
  ################################    RF  Kriging         ################
  fm2 <- as.formula(paste(targetVar," ~x+y+DEM+Slope+NDVI+LUCC2015+LUCC2010+LUCC2005+LUCC2000+LUCC95+LUCC90+LUCC80+GDP15+GDP95+POP15+POP95+DiMao+solitype+PlantType+clay+sand+silt+TWI+Atavg+Aravg",sep="") )
  
  rfModel <- ranger(fm2, trainData, num.trees=500, importance = "impurity", seed=1,respect.unordered.factors="order")
  
  importance<-rfModel$variable.importance/sum(rfModel$variable.importance)
  
  rfPredict<- predict(rfModel,data=testData)
  
  resPredict<- predict(rfModel,data=trainData)
  
  residues<-trainData[,targetVar]-resPredict$predictions
  
  
  trainData$residues<-residues
  
  coordinates(testData) = ~x+y
  coordinates(trainData) = ~x+y
  
  
  vgm.point = variogram(residues~1, trainData)
  
  plot(vgm.point)
  vgm.fit = fit.variogram(vgm.point, model = vgm(1, "Sph", 15000, 1))
  
  residue.kriged<- krige(residues~1, trainData, testData, model = vgm.fit)
  
  pred<-rfPredict$predictions+residue.kriged$var1.pred
  
  mae<-c(mae,mean(abs(testData@data[,targetVar]-pred)))
  
  rmse<-c(rmse, sqrt(mean((testData@data[,targetVar]-pred)^2)))
  
 
   ################################    IDW          ################
  
  idw = krige(as.formula(paste(targetVar,"~1",sep="")), trainData, testData)
  #print(mean(abs(testData[,targetVar]-idw$var1.pred)))
  
  mae<-c(mae,mean(abs(testData@data[,targetVar]-idw$var1.pred)))
  
  rmse<-c(rmse, sqrt(mean((testData@data[,targetVar]-idw$var1.pred)^2)))
  
 
  ################################    Kriging         ################
  
  vgm.point = variogram(as.formula(paste(targetVar,"~1",sep="")), trainData)
  
  plot(vgm.point)
  
  vgm.fit = fit.variogram(vgm.point, model = vgm(1, "Sph", 15000, 1))
  
  #plot(vgm.point, vgm.fit)
  
  pb.kriged<- krige(as.formula(paste(targetVar,"~1",sep="")), trainData, testData, model = vgm.fit)
  
  #print(mean(abs(testData$Cd-pb.kriged$var1.pred)))
  
  mae<-c(mae,mean(abs(testData@data[,targetVar]-pb.kriged$var1.pred)))
  
  rmse<-c(rmse, sqrt(mean((testData@data[,targetVar]-pb.kriged$var1.pred)^2)))
  
  
  resultsMAE<-rbind(resultsMAE,mae)
  
  resultsRMSE<-rbind(resultsRMSE,rmse)
  
}

names(resultsMAE)<-c("RF","TP_RF","RFK","IDW","Kriging")
names(resultsRMSE)<-c("RF","TP_RF","RFK","IDW","Kriging")

write.csv(resultsMAE,file=paste("data\\MAE",targetVar,"_20Inta.csv",sep=""))

write.csv(resultsRMSE,file=paste("data\\RMSE",targetVar,"_20Inta.csv",sep=""))


