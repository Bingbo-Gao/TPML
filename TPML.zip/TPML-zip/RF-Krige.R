setwd("D:\\MyPaper\\Sample\\TPML")

Sys.setenv(JAVA_HOME='C:\\Program Files\\Java\\jre1.8.0_191')

library(xlsx)
library(sp)
library(gstat)


source("basic.r")


data = read.xlsx('BData.xlsx',1,encoding="UTF-8")

data$solitype<-as.factor(data$solitype)
data$DiMao<-as.factor(data$DiMao)
data$PlantType<-as.factor(data$PlantType)
data$LUCC2015<-as.factor(data$LUCC2015)
data$LUCC2010<-as.factor(data$LUCC2010)
data$LUCC2005<-as.factor(data$LUCC2005)
data$LUCC2000<-as.factor(data$LUCC2000)
data$LUCC95<-as.factor(data$LUCC95)
data$LUCC90<-as.factor(data$LUCC90)
data$LUCC80<-as.factor(data$LUCC80)

targetVar<-"TargetVar"
resultsMAE<-c()
resultsRMSE<-c()

for (sSize in seq(100,500,by=100))
{
  mae<-c()
  rmse<-c()
  sample<-read.csv(paste("data\\Sample",sSize,".csv",sep=""))
  trainInd<-sample$ID
  
  #trainInd<-sample(nrow(data),round(nrow(data)*0.7))
  trainData<-data[trainInd,]
  testData<-data[-trainInd,]
  
  ################################ Universal   Kriging         ################
  
  
  fm1 <- as.formula(paste(targetVar," ~x+y+DEM+Slope+NDVI+LUCC2015+LUCC2010+LUCC2005+LUCC2000+LUCC95+LUCC90+LUCC80+GDP15+GDP95+POP15+POP95+DiMao+solitype+PlantType+clay+sand+silt+TWI+Atavg+Aravg",sep="") )
  
  ###  Error:factor vege has new levels 31, 118, 1081, 4341,thus remove vege  
  ###  Error:solitype has new levels 23115152, 23115172,thus remove  solitype
  ###  factor lucc has new levels 12, 22, 24, 43, 52, 53,thus remove  lucc
  ###  factor gemor has new levels 12, 15, 23, 26, 28, 30, 32, 35, 37, 41, 45, 50, 51,thus remove  gemor
  
  lmModel<-lm(fm1,trainData)
  
  lmPredict<-predict(lmModel,trainData)
  
  lmResidues<-trainData[,targetVar]-lmPredict
  
  lmTrendPredict<-predict(lmModel,testData)
  
  
  trainData$residues<-lmResidues
  
  coordinates(testData) = ~x+y
  coordinates(trainData) = ~x+y
  
  
  vgm.point = variogram(residues~1, trainData)
  
  plot(vgm.point)
  vgm.fit = fit.variogram(vgm.point, model = vgm(1, "Sph", 15000, 1))
  
  residue.kriged<- krige(residues~1, trainData, testData, model = vgm.fit)
  
  pred<-lmTrendPredict+residue.kriged$var1.pred
  
  mae<-c(mae,mean(abs(testData@data[,targetVar]-pred)))
  
  rmse<-c(rmse, sqrt(mean((testData@data[,targetVar]-pred)^2)))
  
  ################################ Ordinary   Kriging         ################
  
  vgm.point = variogram(as.formula(paste(targetVar,"~1",sep="")), trainData,cutoff=10000)
  
  #plot(vgm.point)
  
  vgm.fit = fit.variogram(vgm.point, model = vgm(400, "Sph", 15000, 1))
  
  #plot(vgm.point, vgm.fit)
  
  pb.kriged<- krige(as.formula(paste(targetVar,"~1",sep="")), trainData, testData, model = vgm.fit)
  
  # print(mean(abs(testData$Cd-pb.kriged$var1.pred)))
  
  mae<-c(mae,mean(abs(testData@data[,targetVar]-pb.kriged$var1.pred)))
  
  rmse<-c(rmse, sqrt(mean((testData@data[,targetVar]-pb.kriged$var1.pred)^2)))
  
  #print(mae)
  
  resultsMAE<-rbind(resultsMAE,mae)
  
  resultsRMSE<-rbind(resultsRMSE,rmse)
  
}

names(resultsMAE)<-c("RF","TP_RF","RFK"	,"IDW",	"Kriging")
names(resultsRMSE)<-c("RF","TP_RF",	"RFK","IDW",	"Kriging")
write.csv(resultsMAE,file=paste("data\\MAE",targetVar,"_20IntaKrige4.csv",sep=""))

write.csv(resultsRMSE,file=paste("data\\RMSE",targetVar,"_20IntaKrige4.csv",sep=""))


